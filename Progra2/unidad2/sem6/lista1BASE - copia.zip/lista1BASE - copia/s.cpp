//Librerias
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <windows.h>

char clases[5][15]={{"PROGRAMACION"},{"ELECTRONICA"},{"ARTES"},{"DIBUJO"},{"COSTURA"}};//clases definidas en arreglo estatido
//estructura con informacion total
typedef struct{
 char *nom_al;//nombre del inscrito
 int edad;//edad del inscrito
 int id_al;//id unico para el inscrito
}TipoAl; 



int main(){
	
	
	return 0;
}
