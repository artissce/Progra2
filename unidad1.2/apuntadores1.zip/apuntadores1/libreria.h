#include <stdio.h>
#include "apuntadores.h"
