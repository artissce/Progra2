#include "libreria.h"
/*Ana Karen Cuenca Esquivel -177932
Programacion 2
Carrera ITI
cLASE 9-10
bidimensionales dinamicos de estructuras
*/
int main(){
	
	sE=validaEntero("No. de personal: ");
	Personal **dato=(Personal **)malloc(f*sizeof(Personal *));
	int a[sE]={0};
	recibeEmpleado(dato,a);
	
	sC=validaEntero("No. de catalogo: ");
	Catalogo **info=(Catalogo **)malloc(f*sizeof(Catalogo *));
	int b[sC]={0};
	recibeCatalogo(info,b);
	
	imprimeEmpleado(dato,a);
	imprimeCatalogo(info,b);
	
	sV=validaEntero("No. de ventas: ");
	Venta **sell=(Venta **)malloc(f*sizeof(Venta *));
	int c[sV]={0};
	recibeVenta(sell,c);
	imprimeVenta(sell,c);
	
	//Venta **dato=(Venta **)malloc(f*sizeof(Venta *));
	

	/*
	c=validaEntero("No. Registros: ");
	
	for(int i=0; i<f; i++){
		*(dato + i) = (Relacion *)malloc(c*sizeof(Relacion));
	}*/
	
	//egistro(dato,info,sell);
	//imprime(dato,info,sell);
	free(dato);
	free(info);
	free(sell);
	
	return 0;
}

